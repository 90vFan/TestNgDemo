package com.lujiatao.webapplication.domain;

public enum Os {

	ANDROID, IOS

}
