//
// 此文件是由 JavaTM Architecture for XML Binding (JAXB) 引用实现 v2.2.7 生成的
// 请访问 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 在重新编译源模式时, 对此文件的所有修改都将丢失。
// 生成时间: 2019.07.27 时间 11:52:00 AM CST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.lujiatao.com/httpinterface/MobilePhones", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.lujiatao.httpinterface.mobilephones;
