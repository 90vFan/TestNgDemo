package com.lujiatao.httpinterface.domain;

public enum Os {

	ANDROID, IOS

}
